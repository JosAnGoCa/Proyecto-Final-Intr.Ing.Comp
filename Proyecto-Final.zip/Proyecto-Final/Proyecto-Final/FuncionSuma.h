int suma(int numero1, int numero2);
