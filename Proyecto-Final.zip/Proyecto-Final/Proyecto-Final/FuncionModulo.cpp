int modulo(int num1, int num2)
{
	float resultado;
	resultado = num1 % num2;
	return resultado;
}

