int Multiplicacion(int num1, int num2)
{
    int resultado;
    resultado = num1 * num2;
    return resultado;
}
