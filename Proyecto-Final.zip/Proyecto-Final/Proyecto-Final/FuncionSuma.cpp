int suma(int numero1, int numero2)
{
	int resultado;
	resultado = numero1 + numero2;
	return resultado;
} 